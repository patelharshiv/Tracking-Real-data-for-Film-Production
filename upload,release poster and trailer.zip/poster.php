<!DOCTYPE html>
<html>

<head>
<title>TRACKING REAL DATA FOR FILM PRODUCTION</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
h1,h2,h3,h4,h5,h6 {font-family: "Oswald"}
body {
height: 100%;
  opacity: 100%;


  /* Center and scale the image nicely */
  background-position: cover;
  background-repeat: no-repeat;
  background-size: cover;
  font-family: Open Sans;}
</style>
<style>

	#k1
	{
  		color:;
	}
	
</style>
</head>


<body>

 <body class="w3-light-grey">

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="home1.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="AnalystExpert/analystexpertnew.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ANALYSIS EXPERT</a>
    <a href="Feedback\feedbacknew.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">FEEDBACK</a>
    <a href="personalnew.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">PERSONAL PROFILE</a>
    <a href="aboutus/aboutusnew.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ABOUT US</a>
    <a href="Contact\contactnew.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">CONTACT</a>
      <?php 
  
      if(empty($_SESSION['uname'])){?>   
          <a class="w3-bar-item w3-button w3-padding-large w3-hide-small" href="Signin.php">Sign Up</a>
          <a class="w3-bar-item w3-button w3-padding-large w3-hide-small" href="index.php">Login</a>
        <?php
      }
      else{?>
         <a class="w3-bar-item w3-button w3-padding-large w3-hide-small" href="logout.php">Logout</a>
         <a class="w3-bar-item w3-button w3-padding-large w3-hide-small" id="uname2" style="color: white;"><?php echo "Welcome"." ".$_SESSION['uname']; ?></a>
         <?php 
      }
?>
  </div>
</div>
</br>
</br>
</br>
</br>
<form action="upload.php">

  <input type="file" id="myFile" name="filename" value="choose poster">
  <input type="submit" value="Upload poster">

</form>

   
</form>
</body>
















</html>